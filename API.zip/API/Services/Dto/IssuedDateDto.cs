﻿namespace AssetManagement.Dto
{
    public class IssuedDateDto
    {
        public string date { get; set; }
    }
}
